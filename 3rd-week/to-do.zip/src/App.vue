<script>
import TodoHeader from '@/components/TodoHeader.vue';
import TodoList from '@/components/TodoList.vue';
import TodoInput from '@/components/TodoInput.vue';
export default {
  components: {
    TodoHeader,
    TodoList,
    TodoInput,
  },
  data() {
    return {
      todo: [], // empty array init
      current: 'all',
    };
  },
  methods: {
    addTodo(inputMsg) {
      const item = {
        id: Math.random(),
        msg: inputMsg, // text
        completed: false, // completed flag
      };
      this.todo.push(item);
    },
    updateTab(tab) {
      this.current = tab;
    },
    deleteTodo(id) {
      this.todo = this.todo.filter((value) => value.id !== id);
    },
    updateTodo(id) {
      this.todo = this.todo.map((value) => 
        value.id === id ? { ...value, completed: !value.completed } : value
      );
    },
  },
  computed: {
    computedTodo() {
      if(this.current === 'all') {
        return this.todo;
      } else {
        return this.todo.filter((value) => value.completed);
      }
    },
  },
}
</script>
<template>
  <body>
    <div class="todo">
      <TodoHeader v-bind:current="current" v-on:update-tab="updateTab" />
      <!-- TodoList 컴포넌트로 computedTodo 데이터 전달 -->
      <TodoList v-bind:computed-todo="computedTodo" v-on:delete-todo="deleteTodo" v-on:update-todo="updateTodo" />
      <TodoInput v-on:add-todo="addTodo" />
    </div>
  </body>
</template>
<style></style>