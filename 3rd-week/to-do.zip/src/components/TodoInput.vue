<script>
export default {
    data() {
        return {
            inputMsg: '', // data definition
        };
    },
    emits: ["addTodo"],
    methods: {
        addTodo() {
            // console.log(this.inputMsg); // print todo
            this.$emit('addTodo', this.inputMsg); // parent component event call
            this.inputMsg = ""; // reset data
        }
    }
}
</script>
<template>
    <div class="todo__input">
        <!-- data bidirectional binding -->
        <input v-model="inputMsg" type="text" class="todo__input-text" placeholder="할 일을 입력하세요." v-on:keydown.enter="addTodo" />
        <button class="todo__input-btn" v-on:click="addTodo">등록</button>
    </div>
</template>
<style></style>